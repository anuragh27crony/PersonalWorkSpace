
def _url(path):
    return 'https://todo.example.com' + path

